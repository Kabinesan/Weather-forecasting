# Weather-Forecast

<a href= "https://ataaman.github.io/Weather-Forecast/">Check Here</a>

In this Project I used weather API to learn API concept in Javascript and for designing I used Tailwind-CSS
